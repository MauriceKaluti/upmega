<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DeliveryTown extends Model
{
    //

       protected $fillable=['name','amount'];
   
}
