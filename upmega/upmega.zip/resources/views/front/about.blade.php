@extends('upmega.layouts.main')
@section('content')
<title>upmega</title>
<div class="py-3"></div>
<div class="container">
       <div class="row mb-3">
              <div class="col-md-6">
              <img class="img-fluid upmega-round" src="https://codekali.com/images/codekali_icon.png">
              </div>
              <div class="col-md-6">
              <h3>About <span class="text-info">upmega</span></h3>
              </div>
       </div>
</div>
<div class="py-3"></div>
@endsection