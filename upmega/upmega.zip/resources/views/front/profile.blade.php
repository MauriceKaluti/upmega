@extends('upmega.layouts.main')
@section('content')
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>

<div class="container upmega-mobile-pushleft">
 

 </div>

@endsection