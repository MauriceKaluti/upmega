@include('welcome_alert')
@include('customer_update')
@include('home_stats')