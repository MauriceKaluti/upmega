<div class="col-md-6 d-none py-3 d-md-block">
         <div id="authSlider" class="carousel slide" data-bs-ride="true">
            <div class="carousel-indicators">
               <button type="button" data-bs-target="#authSlider" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
               <button type="button" data-bs-target="#authSlider" data-bs-slide-to="1" aria-label="Slide 2"></button>
               <button type="button" data-bs-target="#authSlider" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
               <div class="carousel-item upmega-round active">
                  <img src="https://upmega.com/images/upmega.jpg" class="d-block w-100 img-fluid auth-form-img" alt="upmega">
               </div>
               <div class="carousel-item upmega-round">
                  <img src="https://upmega.com/images/upmega.jpg" class="d-block w-100 img-fluid auth-form-img" alt="upmega">
               </div>
               <div class="carousel-item upmega-round">
                  <img src="https://upmega.com/images/upmega.jpg" class="d-block w-100 img-fluid auth-form-img" alt="upmega">
               </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#authSlider" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"><span class="fa fa-angle-left"></span></span>
            
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#authSlider" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"><span class="fa fa-angle-right"></span></span>
            
            </button>
         </div>
      </div>